﻿/*22
using Microsoft.AspNetCore.Identity;

namespace MyProject.Web.Models
{
    //3
    public class User: IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public int? UsernameChangeLimit { get; set; } = 10;
        public byte[]? ProfilePicture { get; set; }
    }
}
*/